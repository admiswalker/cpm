#pragma once

#include "../matrixContainer_colMajor/mat_c.hpp"

/*
namespace sstd{
}
//*/

