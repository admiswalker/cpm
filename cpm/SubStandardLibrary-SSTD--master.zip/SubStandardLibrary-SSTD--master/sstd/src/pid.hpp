#pragma once
#include "./typeDef.h"

namespace sstd{
    int32 getpid();
}


