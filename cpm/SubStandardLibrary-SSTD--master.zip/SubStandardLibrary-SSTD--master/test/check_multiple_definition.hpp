// Trigger a compilation error if there are multiple definitions.
// In order not to occor "multiple definition error"
// when including <sstd/sstd.hpp> from multi file.
