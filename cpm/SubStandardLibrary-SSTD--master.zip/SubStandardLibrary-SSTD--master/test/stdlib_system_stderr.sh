#!/bin/bash
echo 'hello-stderr' >&2
