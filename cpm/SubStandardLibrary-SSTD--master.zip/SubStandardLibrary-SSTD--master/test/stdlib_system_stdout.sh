#!/bin/bash
echo 'hello-stdout' >&1
